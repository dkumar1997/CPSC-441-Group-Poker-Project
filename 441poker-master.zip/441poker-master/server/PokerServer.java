/*
 * A simple TCP select server that accepts multiple connections and echo message back to the clients
 * For use in CPSC 441 lectures
 * Instructor: Prof. Mea Wang
 */
package server;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.charset.*;
import java.util.*;


public class PokerServer {
    public static int BUFFERSIZE = 64;
    private static int pot = 0;
    private static int currBet = 0;
    private static int playerNum = 0;
    private static int readyPlayers = 0;
    private int numFolded = 0;
    private static boolean gameWon = false;
    private boolean allFolded = false;
    private static HashMap<String, SocketChannel> clients = new HashMap<String, SocketChannel>();
    private static ArrayList<String> players = new ArrayList<String>();
    private static ArrayList<Player> playerObjs = new ArrayList<Player>();
    private String lastMsg;
    
    private Charset charset = Charset.forName( "us-ascii" );  
    private CharsetDecoder decoder = charset.newDecoder();  
    private CharsetEncoder encoder = charset.newEncoder();
    private ByteBuffer inBuffer = null;
    private ByteBuffer outBuffer = null;
    private CharBuffer cBuffer = null;
    
    
    public static void main(String args[]) throws Exception 
    {
    	PokerServer game = new PokerServer();
        if (args.length != 1)
        {
            System.out.println("Usage: PokerServer <Listening Port>");
            System.exit(1);
        }

        // Initialize buffers and coders for channel receive and send
        String line = "";
        
        int bytesSent = 0, bytesRecv;     // number of bytes sent or received
        
        // Initialize the selector
        Selector selector = Selector.open();

        // Create a server channel and make it non-blocking
        ServerSocketChannel channel = ServerSocketChannel.open();
        channel.configureBlocking(false);
       
        // Get the port number and bind the socket
        InetSocketAddress isa = new InetSocketAddress(Integer.parseInt(args[0]));
        channel.socket().bind(isa);

        // Register that the server selector is interested in connection requests
        channel.register(selector, SelectionKey.OP_ACCEPT);

        // TODO end loop if all players leave.
        boolean terminated = false;
        while (!terminated) 
        {	
            if (selector.select(500) < 0)
            {
                System.out.println("select() failed");
                System.exit(1);
            }
            
            // Get set of ready sockets
            Set readyKeys = selector.selectedKeys();
            Iterator readyItor = readyKeys.iterator();
            
            
            boolean startGame = false;
            // TODO end loop when all players are ready
            // TODO get ready status within this loop
            // TODO get spectate status within this loop
            // Walk through the ready set and get connections
            while (readyItor.hasNext() && !startGame)  
            {
                // Get key from set
                SelectionKey key = (SelectionKey)readyItor.next();

                // Remove current entry
                readyItor.remove();

                // Accept new connections, if any
                if (key.isAcceptable())
                {
                    
                    SocketChannel cchannel = ((ServerSocketChannel)key.channel()).accept();
                    cchannel.configureBlocking(false);
                    clients.put(cchannel.socket().toString(), cchannel);
                    players.add(cchannel.socket().toString());
                    playerObjs.add(new Player(Integer.toString((playerNum + 1)), 500, null));
                    playerNum++;
                    System.out.println("Accept conncection from " + cchannel.socket().toString());
                    
                    // Register the new connection for read operation
                    cchannel.register(selector, SelectionKey.OP_READ);
                }
                else 
                {
                    SocketChannel cchannel = (SocketChannel)key.channel();
                    if (key.isReadable())
                    {
                        Socket socket = cchannel.socket();
                    
                        // Open input and output streams
                        game.inBuffer = ByteBuffer.allocateDirect(BUFFERSIZE);
                        game.cBuffer = CharBuffer.allocate(BUFFERSIZE);
                         
                        // Read from socket
                        bytesRecv = cchannel.read(game.inBuffer);
                        if (bytesRecv <= 0)
                        {
                            System.out.println("read() error, or connection closed");
                            key.cancel();  // deregister the socket
                            continue;
                        }
                        
                        game.inBuffer.flip();      // make buffer available  
                        game.decoder.decode(game.inBuffer, game.cBuffer, false);
                        game.cBuffer.flip();
                       
                        line = game.cBuffer.toString();
                        if (line.contains("SIT")) {
                        	readyPlayers++;
                        	System.out.println(readyPlayers);
                        	if (readyPlayers == playerNum && playerNum >= 2) {
                        		startGame = true;
                        		break;
                        	}
                        } else if (line.contains("SPEC")) {
                        	readyPlayers++;
                        	int plIndex = players.indexOf(cchannel.socket().toString());
                        	playerObjs.get(plIndex).folded = true;
                        	game.numFolded++;
                        	if (readyPlayers == playerNum && playerNum > 2) {
                        		startGame = true;
                        		break;
                        	}
                        } else if (line.contains("LEAVE")) {
                        	key.cancel();
                        	playerNum--;
                        	players.remove(cchannel.socket().toString());
                        	if (playerNum == 0) {
                        		terminated = true;
                        		break;
                        	}
                        	if (readyPlayers == playerNum && playerNum > 2) {
                        		startGame = true;
                        		break;
                        	}
                        	continue;
                        }
                     }
                } 
            }
           
            //start game
            if (startGame) {
	            game.start();
	            game.resetGame();
            }
            
        }
 
        // close all connections
        Set keys = selector.keys();
        Iterator itr = keys.iterator();
        while (itr.hasNext()) 
        {
            SelectionKey key = (SelectionKey)itr.next();
            //itr.remove();
            if (key.isAcceptable())
                ((ServerSocketChannel)key.channel()).socket().close();
            else if (key.isValid())
                ((SocketChannel)key.channel()).socket().close();
        }
    }
    
    public void resetGame() {
    	for (Player pl : playerObjs) {
    		pl.folded = false;
    	}
    	pot = 0;
    	currBet = 0;
    	numFolded = 0;
    	readyPlayers = 0;
    	allFolded = false;
    }
    
    public void start() throws Exception{
    	inBuffer = ByteBuffer.allocateDirect(BUFFERSIZE);
        outBuffer = ByteBuffer.allocateDirect(BUFFERSIZE);
        cBuffer = CharBuffer.allocate(BUFFERSIZE);
        
        Deck allcards = new Deck();
        Board board = new Board(allcards);
        allcards.builddeck();
        allcards.shuffledeck();
        SocketChannel cchannel = null;
        String player = null;
        // send game start message to all players
        for (int i = 0; i < players.size(); i++) {
        	player = players.get(i);
        	cchannel = clients.get(player);
        	outBuffer = encoder.encode(CharBuffer.wrap("START " + playerNum + "\n"));
        	cchannel.write(outBuffer);
        }
        
        // send all players their player number and their money.
        // TODO check if player is spectating
        player = null;
        cchannel = null;
        for (int i = 0; i < players.size(); i++) {
        	player = players.get(i);
        	cchannel = clients.get(player);
        	outBuffer = encoder.encode(CharBuffer.wrap("PLNUM " + Integer.toString(i+1) + "\n"));
            cchannel.write(outBuffer);
            outBuffer = encoder.encode(CharBuffer.wrap("UPDMONEY " + Integer.toString(500) + "\n"));
            cchannel.write(outBuffer);
            //playerObjs.add(new Player(Integer.toString(i+1), 500, allcards)); /////////////////////////move up to connection establishing to let spectate be a thing.
            playerObjs.get(i).deck = allcards;
        }
        
        //send all players their cards.
        player = null;
        cchannel = null;
        Player pl = null;
        for (int i = 0; i < players.size(); i++) {
        	if (playerObjs.get(i).folded) {
        		player = players.get(i);
            	cchannel = clients.get(player);
            	pl.origHand = null;
            	outBuffer = encoder.encode(CharBuffer.wrap("PLCARDS NONE \n"));
            	cchannel.write(outBuffer);
        	} else {
        		player = players.get(i);
            	cchannel = clients.get(player);
            	pl = playerObjs.get(i);
            	pl.addcards();
            	pl.origHand = new ArrayList<Cards>(pl.hand);
            	outBuffer = encoder.encode(CharBuffer.wrap("PLCARDS " + pl.handAsString() + "\n"));
            	cchannel.write(outBuffer);
        	}
        }
        
        //start the first betting round
        betRound();
        checkFolds();
        if (gameWon) return; 
        
        //update board, players and start second betting round
        board.firstthree();
        updateAllPlayers(board);
        betRound();
        checkFolds();
        if (gameWon) return; 
        
        //update board, players and start third betting round
        board.turncard();
        updateAllPlayers(board);
        betRound();
        checkFolds();
        if (gameWon) return; 
        
        //update board, players and start last betting round
        board.rivercard();
        updateAllPlayers(board);
        betRound();
        checkFolds();
        if (gameWon) return; 
        
        determineWinner(board);
        sendOTPlayerHands();
    }
    
    public void betRound() {
    	int plTurn = 0;
        int lastPl = players.size() - 1;
        boolean betRoundOver = false;
        Player plOb = null;
    	String player = null;
    	SocketChannel cchannel = null;
    	inBuffer = ByteBuffer.allocateDirect(BUFFERSIZE);
    	
    	plOb = playerObjs.get(lastPl);
    	while (plOb.folded || plOb.disconnected) {
    		lastPl = (lastPl - 1) % players.size();
    		plOb = playerObjs.get(lastPl);
    	} 
    	
        while (!betRoundOver) {
        	
        	// loop through players to make sure turn is not given to folded / dc'ed player
        	plOb = playerObjs.get(plTurn % players.size());
        	while (plOb.folded || plOb.disconnected) {
        		plTurn++;
        		plOb = playerObjs.get(plTurn % players.size());
        	}
        	
        	//make sure last player is not folded or dc'ed
        	plOb = playerObjs.get(lastPl);
        	while (plOb.folded || plOb.disconnected) {
        		lastPl = (lastPl + 1) % players.size();
        		plOb = playerObjs.get(lastPl);
        	
        	//send message to all players about who's turn it is.
        	for (int i = 0; i < players.size(); i++) {
        		try {
	        		if (i == (plTurn % players.size())) {
	        			player = players.get(i);
	                	cchannel = clients.get(player);
						outBuffer = encoder.encode(CharBuffer.wrap("PLTURN" + "\n"));
						cchannel.write(outBuffer);
	        		} else if (!playerObjs.get(i).disconnected) {
	        			player = players.get(i);
	                	cchannel = clients.get(player);
						outBuffer = encoder.encode(CharBuffer.wrap("TURN " + Integer.toString((plTurn % players.size() )+ 1) + "\n"));
						cchannel.write(outBuffer);
	        		}
        		} catch (CharacterCodingException e) {
					e.printStackTrace();
				} catch (IOException ioe) {
					System.out.println("caught exception");
					playerObjs.get(i).folded = true;
					playerObjs.get(i).disconnected = true;
				}
        	}
        	
        	boolean received = false;
        	String msg = "";
        	player = players.get(plTurn % players.size());
        	System.out.println(player);
        	cchannel = clients.get(player);
        	int bytesRead = 0;
        	try {
        		
                inBuffer.clear();
                cBuffer.clear();
				while ((bytesRead = cchannel.read(inBuffer)) == 0) {inBuffer.clear();}
				inBuffer.flip();      // make buffer available
			    decoder.decode(inBuffer, cBuffer, false);
			    cBuffer.flip();
			    
			    msg = cBuffer.toString();
			    
			} catch (IOException e) {
				e.printStackTrace();
			}
        	System.out.println("TCP Client: " + msg + plTurn + lastPl);
        	if ((plTurn % players.size() == lastPl) && msg.contains("RAISE")) {
        		lastPl = (plTurn + 1) % players.size();
        	} else if (plTurn % players.size() == lastPl) {
        		betRoundOver = true;
        	}
        	decodeMsg(msg.trim(), plTurn % players.size());
        	checkFolds();
        	if (gameWon) return;
        	plTurn++; 
        }
        
        //tell players that bet round is over
        for (int i = 0; i < players.size(); i++) {
    		try {
        		if (!playerObjs.get(i).disconnected) {
        			player = players.get(i);
                	cchannel = clients.get(player);
					outBuffer = encoder.encode(CharBuffer.wrap("BETRDONE" + "\n"));
					cchannel.write(outBuffer);
        		}
    		} catch (CharacterCodingException e) {
				e.printStackTrace();
			} catch (IOException ioe) {
				playerObjs.get(i).folded = true;
				playerObjs.get(i).disconnected = true;
			}
    	}
        currBet = 0;
        plTurn = 0;
        }
    }
    
    public void decodeMsg(String msg, int plNum) {
    	if (msg.toLowerCase().contains("raise")) {
    		int raiseAmnt = Integer.parseInt(msg.substring(6));
    		playerObjs.get(plNum).howmuchworth -= raiseAmnt + currBet;
    		currBet += raiseAmnt;
    		pot += raiseAmnt;
    		updatePlAction("raise", raiseAmnt, plNum);
    	} else if (msg.toLowerCase().contains("call")){
    		if (playerObjs.get(plNum).getvalue() < currBet) {
    			pot += playerObjs.get(plNum).getvalue();
    			playerObjs.get(plNum).howmuchworth = 0;
    		} else {
    			pot += currBet;
    			playerObjs.get(plNum).howmuchworth -= currBet;
    		}
    		updatePlAction("call", plNum);
    	} else if (msg.toLowerCase().contains("check")) {
    		updatePlAction("check", plNum);
    	} else if (msg.toLowerCase().contains("fold")) {
    		numFolded++;
    		playerObjs.get(plNum).folded = true;
    		updatePlAction("fold", plNum);
    	}
    }
    
    public void updatePlAction(String call, int amnt, int pl) {
    	String player = null;
    	SocketChannel cchannel = null;
    	try {
	        for (int i = 0; i < players.size(); i++) {
	        	player = players.get(i);
	        	cchannel = clients.get(player);
	        	outBuffer = encoder.encode(CharBuffer.wrap("RAISE " + amnt + " " + pl + "\n"));
	            cchannel.write(outBuffer);
	        }
    	} catch (IOException ioe) {
    		ioe.printStackTrace();
    	}
    }
    
    public void updatePlAction(String call, int pl) {
    	String player = null;
    	SocketChannel cchannel = null;
    	try {
	        for (int i = 0; i < players.size(); i++) {
	        	player = players.get(i);
	        	cchannel = clients.get(player);
	        	outBuffer = encoder.encode(CharBuffer.wrap(call.toUpperCase() + " " + pl + "\n"));
	            cchannel.write(outBuffer);
	        }
    	} catch (IOException ioe) {
    		ioe.printStackTrace();
    	}
    }
    
    public void updateAllPlayers(Board board) {
    	//send board cards
    	//send current pot
    	//send current money
    	String player = null;
        SocketChannel cchannel = null;
        Player pl = null;
        for (int i = 0; i < players.size(); i++) {
        	try {
        		if (!playerObjs.get(i).disconnected) {
		        	player = players.get(i);
		        	cchannel = clients.get(player);
		        	outBuffer = encoder.encode(CharBuffer.wrap("UPDCRD " + board.boardAsString() + "\n"));
		        	cchannel.write(outBuffer);
		        	
		        	outBuffer = encoder.encode(CharBuffer.wrap("UPDPOT " + pot + "\n"));
		        	cchannel.write(outBuffer);
		        	
		        	outBuffer = encoder.encode(CharBuffer.wrap("UPDMONEY " + playerObjs.get(i).getvalue() + "\n"));
		        	cchannel.write(outBuffer);
		        	
		        	for (int j = 0; j < players.size(); j++) { 
	        			outBuffer = encoder.encode(CharBuffer.wrap("UPDOTMON " + (j + 1) + " " + playerObjs.get(j).getvalue() + "\n"));
	    	        	cchannel.write(outBuffer);	
		        	}
        		}
	        } catch (CharacterCodingException e) {
				e.printStackTrace();
			} catch (IOException ioe) {
				System.out.println("caught exception");
				playerObjs.get(i).folded = true;
				playerObjs.get(i).disconnected = true;
			}
        }
    }
    
    public void determineWinner(Board board) {
		Evaluate eval = new Evaluate();
		Cards[] handArr;
		
		for (Player pl : playerObjs) {
			pl.hand.addAll(board.getBoard());
			pl.hand.sort(null);
			handArr = (Cards[]) pl.handToArray();
			eval.evalHand(handArr, pl);
		}
		int winningPl = -1;
		Player pl = null;
		int winningHand = 1;
		ArrayList<Integer> tiedPlayers = new ArrayList<Integer>();
		for (int i = 0; i < players.size(); i++) {
			if (playerObjs.get(i).handVal == 10) {
				winningHand = playerObjs.get(i).handVal;
				winningPl = i;
			} else if (playerObjs.get(i).handVal > winningHand) {
				winningHand = playerObjs.get(i).handVal;
				winningPl = i;
			} else if (playerObjs.get(i).handVal == winningHand) {
				tiedPlayers.add(i);
			}
		}

		ArrayList<Integer> secondaryTie = new ArrayList<Integer>();
		if (tiedPlayers.size() > 0) {
			secondaryTie.add(tiedPlayers.get(0));
			Cards highCard = playerObjs.get(secondaryTie.get(0)).highCard;
			for (int i = 1; i < tiedPlayers.size(); i ++) {
				if (playerObjs.get(i).highCard.getnumber() == 1) {
					winningHand = playerObjs.get(tiedPlayers.get(i)).handVal;
					winningPl = i;
					secondaryTie.add(tiedPlayers.get(i));
				} else if (playerObjs.get(tiedPlayers.get(i)).highCard.getnumber() == highCard.getnumber()) {
					secondaryTie.add(tiedPlayers.get(i));
				} else if (playerObjs.get(tiedPlayers.get(i)).highCard.getnumber() > highCard.getnumber()){
					highCard = playerObjs.get(tiedPlayers.get(i)).highCard;
					winningPl = tiedPlayers.get(i);
				}
				
			}
			if (secondaryTie.size() > 1) {
				System.out.println("going into second");
				splitPot(secondaryTie);
			} else {
				win(winningPl);
			}
		} else {
			win(winningPl);
		}
	}
    
    public void sendPlHand() {
    	String player = null;
        SocketChannel cchannel = null;
        Player pl = null;
        try {
	        for (int i = 0; i < players.size(); i++) {
	        	pl = playerObjs.get(i);
	        	player = players.get(i);
				cchannel = clients.get(player);
				outBuffer = encoder.encode(CharBuffer.wrap("HAND " + pl.handType + "\n"));
				cchannel.write(outBuffer);
	        }
        } catch (CharacterCodingException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
    }
    
    public void sendOTPlayerHands() {
    	String player = null;
        SocketChannel cchannel = null;
        Player pl = null;
        try {
        	for (int i = 0; i < playerObjs.size(); i++) {
        		pl = playerObjs.get(i);
        		if (pl.origHand == null) continue;
        		for (int j = 0; j < playerObjs.size(); j++) {
        			outBuffer = encoder.encode(CharBuffer.wrap("OTHAND " + i + " " + pl.origHandAsString() + "\n"));
        			if (pl.disconnected) {
        				continue;
        			} else if (j != i) {
		    			player = players.get(j);
		    			cchannel = clients.get(player);
		    			cchannel.write(outBuffer);
        			}
        		}
			}
		} catch (CharacterCodingException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
    }
    
    public void win(int winningPl) {
    	//send all players what their hand was
    	//send who won to all players
    	String player = null;
        SocketChannel cchannel = null;
        Player pl = null;
        Player plWin = playerObjs.get(winningPl);
        try {
	        if (allFolded) {
	        	for (int i = 0; i < players.size(); i++) {
		        	player = players.get(i);
		        	cchannel = clients.get(player);
		        	outBuffer = encoder.encode(CharBuffer.wrap("WINF " + winningPl + "\n"));
		        	//System.out.println("WIN " + (winningPl + 1) + " " + plWin.handType);
					cchannel.write(outBuffer);
	        	}
				gameWon = true;
				return;
	        }
	        for (int i = 0; i < players.size(); i++) {
	        	
	        		player = players.get(i);
	            	cchannel = clients.get(player);
	            	outBuffer = encoder.encode(CharBuffer.wrap("WIN " + winningPl + " " + plWin.handType.replace(" ", "-") + "\n"));
	            	System.out.println("WIN " + (winningPl + 1) + " " + plWin.handType);
					cchannel.write(outBuffer);
	        }
		} catch (IOException e) {
			e.printStackTrace();
        }
    }
    
    public void splitPot(ArrayList<Integer> tiedPlayers) {
    	//send info about the split pot
    	String player = null;
        SocketChannel cchannel = null;
        Player pl = null;
        String winHandType = playerObjs.get(tiedPlayers.get(0)).handType;
        String tiedPls = Integer.toString(tiedPlayers.get(0));
        for (int i = 1; i < tiedPlayers.size(); i++) {
        	tiedPls = tiedPls + "," + tiedPlayers.get(i);
        }
        
        for (int i = 0; i < players.size(); i++) {
        	try {
        		player = players.get(i);
            	cchannel = clients.get(player);
            	outBuffer = encoder.encode(CharBuffer.wrap("SPLIT " + tiedPlayers.size() + " " + tiedPls + " " + winHandType.replace(" ", "/") + "\n"));
            	System.out.println("SPLIT " + tiedPlayers.size() + " " + tiedPls + " " + winHandType.replace(" ", "/"));
				cchannel.write(outBuffer);
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
    }
    
    public void checkFolds() {
    	for (int i = 0; i < playerObjs.size(); i++) {
    		if (!playerObjs.get(i).folded && numFolded == players.size() - 1) {
    			allFolded = true;
    			win(i);
    			break;
    		}
    	}
    }
}
