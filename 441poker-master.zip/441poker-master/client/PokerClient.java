/*
 * A simple TCP client that sends messages to a server and display the message
   from the server. 
 * For use in CPSC 441 lectures
 * Instructor: Prof. Mea Wang
 */
package client;

import java.io.*; 
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner; 

class PokerClient { 
	
	private int plNum;
	private int plMoney;
	private int numOfPlayers = 3; //need to receive from server if dynamic number of players is implemented.
	private ArrayList<Cards> plHand = new ArrayList<Cards>();
	private ArrayList<Cards> dlHand = new ArrayList<Cards>();
	private int plTurn = 0;
	private boolean betRoundOver = false;
	private boolean gameOver = false;
	private boolean spectator = false;
	private int pot = 0;
	private int currBet = 0;
	private int numFolded = 0;
	private PrintWriter outBuffer;
	private BufferedReader inBuffer;
	private BufferedReader inFromUser;
	private static Socket clientSocket = null;
	
    public static void main(String args[]) throws Exception 
    { 
        if (args.length != 2)
        {
            System.out.println("Usage: PokerClient <Server IP> <Server Port>");
            System.exit(1);
        }
        PokerClient game = new PokerClient();
        // Initialize a client socket connection to the server
        clientSocket = new Socket(args[0], Integer.parseInt(args[1])); 

        // Initialize input and an output stream for the connection(s)
		game.outBuffer =
			new PrintWriter(clientSocket.getOutputStream(), true);
		
        game.inBuffer = 
          new BufferedReader(new
          InputStreamReader(clientSocket.getInputStream())); 

        game.inFromUser = 
                new BufferedReader(new InputStreamReader(System.in)); 
        String msg; 
	      
        //start game
        
        System.out.println("Welcome to Poker");
        
        // TODO game while loop here until player decides to leave.
        while (true) {
        	
        	game.currBet = 0;
        	game.pot = 0;
        	game.numFolded = 0;
        	
        	System.out.println("\n\nThe game is about to begin");
	        String line = "";
	        game.printStartOps();
	        line = game.inFromUser.readLine();
	        msg = game.encodeMsg(line, game.inFromUser);
	        game.outBuffer.println(msg.trim());
	        if (msg.contains("LEAVE")) {
	        	clientSocket.close();
	        	System.exit(0);
	        } else if (msg.contains("SPEC")) {
	        	game.spectator = true;
	        }
	        
	        System.out.println("Waiting for other players");
	        
	        // wait for start message 
	        while ((msg = game.inBuffer.readLine()) == null) {}
	    	game.decodeMsg(msg);
	    	
	    	System.out.println("The game is beginning");
	    	
	        //get player number and money
	        while ((msg = game.inBuffer.readLine()) == null) {}
	    	game.decodeMsg(msg);
	    	while ((msg = game.inBuffer.readLine()) == null) {}
	    	game.decodeMsg(msg);
	    	
	    	//get the player's hand
	    	while ((msg = game.inBuffer.readLine()) == null) {}
	    	if (!game.spectator) {	
	    		game.decodeMsg(msg);
	    		game.printHand();
	    	}
	    	System.out.println();
	    	
	    	System.out.println("\n===========Beginning the first betting round===========");
	    	game.betRound();
	    	if (game.gameOver) continue;
	    	
	    	System.out.println("\n==========Beginning the second betting round===========");
	    	game.update();
	    	game.betRound();
	    	if (game.gameOver) continue;
	    	
	    	System.out.println("\n===========Beginning the third betting round===========");
	    	game.update();
	    	game.betRound();
	    	if (game.gameOver) continue;
	    	
	    	System.out.println("\n===========Beginning the last betting round============");
	    	game.update();
	    	game.betRound();
	    	if (game.gameOver) continue;
	    	
	    	game.getWinner();
	    	game.getOtHands();
	    	
	    	game.gameOver = false;
	    	// TODO prompt user to leave or stay here
        }         
    } 
    
    public String encodeMsg(String msgOg, BufferedReader inFromUser) {
    	int raiseAmnt = 0;
    	String msg = null;
    	if (msgOg.toLowerCase().contains("raise")) {
    		raiseAmnt = todo(msgOg, inFromUser);
    		msg = "RAISE " + raiseAmnt;
    	} else if (msgOg.toLowerCase().contains("call")){
    		msg = "CALL";
    	} else if (msgOg.toLowerCase().contains("check")) {
    		msg = "CHECK";
    	} else if (msgOg.toLowerCase().contains("fold")) {
    		msg = "FOLD";
    	} else if (msgOg.toLowerCase().contains("sit down")) {
    		msg = "SIT";
    	} else if (msgOg.toLowerCase().contains("spectate")) {
    		msg = "SPEC";
    	} else if (msgOg.toLowerCase().contains("leave")) {
    		msg = "LEAVE";
    	}
    	return msg;
    }
    
    public void decodeMsg(String msg) throws IOException {
    	if (msg.contains("START")) {
    		numOfPlayers = Integer.parseInt(msg.substring(6));
    	} else if (msg.contains("PLNUM")) {
    		plNum = Integer.parseInt(msg.substring(6));
    		System.out.println("Your player number is " + plNum);
    	} else if (msg.contains("UPDMONEY")) {
    		plMoney = Integer.parseInt(msg.substring(9));
    	} else if (msg.contains("PLCARDS")) {
    		if (!spectator) {
    			plHand = handFromString(msg.substring(8));
    		}
    	} else if (msg.contains("PLTURN")) {
    		plTurn = plNum;
    	} else if (msg.contains("TURN")) {
    		plTurn = Integer.parseInt(msg.substring(5));
    	} else if (msg.contains("BETRDONE")) {
    		betRoundOver = true;
    		System.out.println("End of betting round");
    	} else if (msg.toLowerCase().contains("raise")) {
    		String[] msgArgs = msg.split(" ");
    		int raiseAmnt = Integer.parseInt(msgArgs[1]);
    		currBet += raiseAmnt;
    		pot += raiseAmnt;
    		if (Integer.parseInt(msgArgs[2]) + 1 == plNum) {
    			System.out.println("You raised by " + raiseAmnt);
    			plMoney -= currBet + raiseAmnt;
    		} else {
    			System.out.println("Player " + (Integer.parseInt(msgArgs[2]) + 1) + " raised by " + raiseAmnt);
    		}
    	} else if (msg.toLowerCase().contains("call")){
    		pot += currBet;
    		if (Integer.parseInt(msg.substring(5)) + 1 == plNum) {
    			System.out.println("You called");
    			plMoney -= currBet;
    		} else {
    			System.out.println("Player " + (Integer.parseInt(msg.substring(5)) + 1) + " called");
    		}
    	} else if (msg.toLowerCase().contains("check")) {
    		if (Integer.parseInt(msg.substring(6)) + 1 == plNum) {
    			System.out.println("You checked");
    		} else {
    			System.out.println("Player " + (Integer.parseInt(msg.substring(6)) + 1) + " checked");
    		}		
    	} else if (msg.toLowerCase().contains("fold")) {
    		if ((Integer.parseInt(msg.substring(5)) + 1) == plNum) {
    			System.out.println("You folded");
    			//plNum = -1;
    			numFolded++;
    			if (numFolded == numOfPlayers - 1) {
	    			winF();
    			}
    		} else {
	    		System.out.println("Player " + (Integer.parseInt(msg.substring(5)) + 1) + " folded");
	    		numFolded++;
	    		if (numFolded == numOfPlayers - 1) {
	    			winF();
	    		}
    		}
    	} else if (msg.toLowerCase().contains("updcrd")) {
    		dlHand = handFromString(msg.substring(7));
    	} else if (msg.toLowerCase().contains("updpot")) {
    		pot = Integer.parseInt(msg.substring(7));
    	} else if (msg.toLowerCase().contains("updbet")) {
    		currBet = Integer.parseInt(msg.substring(7));
    	} else if (msg.toLowerCase().contains("updotmon")) {
    		String[] msgArgs = msg.split(" ");
    		System.out.println("Player " + (Integer.parseInt(msgArgs[1])) + " has $" + msgArgs[2]);
    	} else if (msg.toLowerCase().contains("othand")) {
    		String[] msgArgs = msg.split(" ");
    		ArrayList<Cards> temp = new ArrayList<Cards>();
    		temp = handFromString(msgArgs[2]);
    		temp.addAll(dlHand);
    		System.out.println("Player " + (Integer.parseInt(msgArgs[1]) + 1) + "'s hand: ");
    		printOtHand(temp);
    	} 
    }
    
    public void betRound() {
    	try {
    		String msg = null;
    		betRoundOver = false;
	    	while (!betRoundOver) {
	    		while ((msg = inBuffer.readLine()) == null) {}
		    	decodeMsg(msg);
		    	if (betRoundOver) break;
	    		printDlHand();
		    	if (!spectator) printHand();
		    	System.out.println("\t You have $" + plMoney);
		    	System.out.print("\nCurrent pot is $" + pot);
		    	System.out.println("\t Current bet is $" + currBet);
		    	
		    	if (plNum == plTurn) {
		    		System.out.println("It's your turn");
		    		whatdo();
		    		String action = inFromUser.readLine();
		    		action = encodeMsg(action, inFromUser);
		    		outBuffer.println(action.trim());
		    		while ((msg = inBuffer.readLine()) == null) {}
		        	decodeMsg(msg);
		        	if (betRoundOver || gameOver) break;
		    	} else {
		    		System.out.println("It is player " + (plTurn) + "'s turn.");
		    		while ((msg = inBuffer.readLine()) == null) {}
		        	decodeMsg(msg);
		        	if (betRoundOver || gameOver) break;
		    	}
	    	}
	    	currBet = 0;
	    	plTurn = 0;
    	} catch (IOException ioe) {
    		ioe.printStackTrace();
    	}
    }
    
    public void whatdo(){
    	if (currBet == 0) {
    		System.out.println("What would you like to do?");
            System.out.println("Raise, Check, Fold?");
    	} else {
    		 System.out.println("What would you like to do?");
    	     System.out.println("Raise, Call, Fold?");
    	}
        System.out.print(": ");
    }
    
    public void printStartOps() {
    	System.out.println("What would you like to do?");
    	System.out.println("Sit down, Spectate, Leave?");
    	System.out.print(": ");
    }
    
    public int todo(String choice, BufferedReader reader){
        int amount = 0;
        boolean validAmnt = false;
        System.out.println("How much would you like to raise by, no decimals");
        try {
        	while (!validAmnt) {
        		amount = Integer.parseInt(reader.readLine());
        		if ((amount > plMoney) || amount < 0) {
        			System.out.println("You can't raise by that. Choose another amount");
        		} else if (amount == plMoney) {
        			System.out.println("All In!");
        			validAmnt = true;
        		} else {
        			validAmnt = true;
        		}
        	}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        
        return amount;
    }
    
    public void update() {
    	//receive the first three board cards
    	//receive current pot
    	//receive current money
    	//receive other player's money count
    	String msg = null;
    	try {
    		while ((msg = inBuffer.readLine()) == null) {}
    		decodeMsg(msg);
    		
    		msg = null;
    		while ((msg = inBuffer.readLine()) == null) {}
    		decodeMsg(msg);
    		
    		msg = null;
    		while ((msg = inBuffer.readLine()) == null) {}
    		decodeMsg(msg);
    		
    		for (int i = 0; i < numOfPlayers; i++) {
    			msg = null;
    			while ((msg = inBuffer.readLine()) == null) {}
        		decodeMsg(msg);
    		}
    	} catch (IOException ioe) {
    		ioe.printStackTrace();
    	}
    }
    
    public void getWinner() {
    	String msg = null;
    	try {
			while ((msg = inBuffer.readLine()) == null) {}
			decodeMsg(msg);
			if (msg.toLowerCase().contains("win")) {
				String[] msgArgs = msg.split(" ");
				String handType = msgArgs[2];
				String[] cardParts = null;
				if (msgArgs[2].replace("-", " ").contains("High Card")) {
					cardParts = msgArgs[2].substring(11).split("/");
					Cards card = new Cards(Integer.parseInt(cardParts[0]), cardParts[1]);
					handType = "High Card: " + card.cardToString();
				}
				
				if (Integer.parseInt(msgArgs[1]) + 1 == plNum) {
					System.out.println("You won the pot with a " + handType.replace("-", " "));
					plMoney += pot;
				} else {
					System.out.println("Player " + (Integer.parseInt(msgArgs[1]) + 1) + " won with a " + handType.replace("-", " "));
				}
			} else if (msg.toLowerCase().contains("split")) {
				String[] msgArgs = msg.split(" ");
				System.out.println("Players " + msgArgs[2] + " split the pot with a " + msgArgs[3]);
				plMoney = plMoney + (pot / Integer.parseInt(msgArgs[1]));
			}
			gameOver = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
    }
    
    public void winF() {
    	String msg = null;
    	try {
			while ((msg = inBuffer.readLine()) == null) {}
			if (msg.toLowerCase().contains("winf")) {
				int winner = Integer.parseInt(msg.substring(5)) + 1;
				if (winner == plNum) {
					System.out.println("You won the pot as everyone else folded");
				} else {
					System.out.println("Player " + winner + " won the pot as everyone else folded");
				}
				
			}
			gameOver = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public void getOtHands() {
    	String msg = null;
    	for (int i = 0; i < numOfPlayers -1; i++) {
    		try {
				while ((msg = inBuffer.readLine()) == null) {}
				decodeMsg(msg);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
    	}
    }
    
    
    
    public ArrayList<Cards> handFromString(String msg) {
    	String cards[] = msg.split(",");
    	ArrayList<Cards> temp = new ArrayList<Cards>();
    	int num = 0;
    	String suit = null;
    	String cardParts[] = null;
    	for (String card : cards) {
    		cardParts = card.split("/");
    		temp.add(new Cards(Integer.parseInt(cardParts[0]), cardParts[1]));
    	}
    	return temp;
    }
    
    public void printHand() {
    	System.out.print("Your hand: " + plHand.get(0).cardToString() + ", " + plHand.get(1).cardToString());
    }
    
    public void printDlHand() {
    	System.out.print("Dealer's hand: ");
    	for (int i = 0; i < dlHand.size(); i++) {
    		if (i == dlHand.size() - 1) {
    			System.out.print(dlHand.get(i).cardToString());
    		} else {
    			System.out.print(dlHand.get(i).cardToString() + ", ");
    		}
    	}
    	System.out.println();
    }
    
    public void printOtHand(ArrayList<Cards> otHand) {
    	for (int i = 0; i < otHand.size(); i++) {
    		if (i == otHand.size() - 1) {
    			System.out.print(otHand.get(i).cardToString());
    		} else {
    			System.out.print(otHand.get(i).cardToString() + ", ");
    		}
    	}
    	System.out.println();
    }
} 
