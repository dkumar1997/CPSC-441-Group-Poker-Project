import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dheeraj
 */
public class Hands {
    private int card1;
    private int card2;
    private ArrayList<Integer> board;
    public Hands(int card1 , int card2, ArrayList<Integer> board){
        this.card1 = card1;
        this.card2 = card2;
        this.board = board;
    }
    
    public String checkboard(){
        
        return null;
    }
}
